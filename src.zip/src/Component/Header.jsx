import React from 'react';
import Home from './Home';
import About from './About-Us';

// Images
import logo from './dankin-logo.png'

import {
    BrowserRouter as Router,
    Routes,
    Route,
    Link,
  } from "react-router-dom";

function Header(props) {
    return (
       <>
       <Router>
            <nav className="navbar navbar-expand-lg navbar-dark bg-dark p-3">
                <div className="container-fluid">
                    <Link className="navbar-logo" to={'/home'}>
                        <img src={logo} className="logo" alt="logo" />
                    </Link>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
                    <div className="navbar-nav">
                        <Link className="nav-link active" aria-current="page" to={'/Home'}>Home</Link>
                        <Link className="nav-link" to={'/about'}>About Us</Link>
                        <a className="nav-link" href="#">Menu</a>
                        <a className="nav-link" href="#">Locate Us</a>
                        <a className="nav-link" href="#">Feedback</a>
                        <a className="nav-link btn btn-primary" href="#">Takeaway</a>
                    </div>
                    </div>
                </div>
                </nav>
        <Routes>
            <Route path='/home' element={<Home/>} />
            <Route path='/about' element={<About/>} />
        </Routes>
        </Router>
       </>
    );
}

export default Header;