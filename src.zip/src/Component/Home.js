import React, { Component } from 'react';

class Home extends Component {
    render() {
        return (
            <div className='home-page text-center p-5'>
                <h1>Welcome to Dunkin Donner!</h1>
            </div>
        );
    }
}

export default Home;