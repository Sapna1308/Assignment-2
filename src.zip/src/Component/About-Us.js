import React, { Component } from 'react';

class About extends Component {
    render() {
        return (
            <div className='about-page text-center p-5'>
                <h1>About Dunkin' India!</h1>
            </div>
        );
    }
}

export default About;